/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package solid;

/**
 *
 * @author duong
 */
public class GeometryCalculator {
    public static void printShapeInfo(Shape shape) {
        System.out.println("Diện tích: " + shape.calculateArea());
        System.out.println("Chu vi: " + shape.calculatePerimeter());
    }
}
