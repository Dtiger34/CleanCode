/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package solid;

/**
 *
 * @author duong
 */
public class SOLID {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Shape circle = new Circle(5);
        Shape square = new Square(4);
        Shape triangle = new RectangleTriangle(3, 4);
        Shape ellipse = new Ellipse(6, 4);

        GeometryCalculator.printShapeInfo(circle);
        GeometryCalculator.printShapeInfo(square);
        GeometryCalculator.printShapeInfo(triangle);
        GeometryCalculator.printShapeInfo(ellipse);
    }
    
}
