package contract;

public interface IBorrowable {
    void borrow();
    void returnBook();
}
