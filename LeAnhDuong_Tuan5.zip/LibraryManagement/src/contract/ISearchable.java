package contract;

public interface ISearchable {
    boolean search(String keyword);
}
