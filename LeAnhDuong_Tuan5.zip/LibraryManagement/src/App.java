import model.Author;
import model.Book;
import model.Library;

public class App {
    public static void main(String[] args) throws Exception {
         Library<Book> library = new Library<>();
        
        Author author1 = new Author("A001", "J.K. Rowling", "British");
        Book book1 = new Book("B001", "Harry Potter", author1, "Fantasy", 10);
        
        library.addItem(book1);
        
        System.out.println("Library contains:");
        for (Book book : library.getItems()) {
            System.out.println("Book: " + book.getTitle());
        }
        
        book1.borrow();
        book1.returnBook();
    }
    }

