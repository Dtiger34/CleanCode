package annotation;

public @interface Entity {
    // Annotation này chỉ dùng để đánh dấu các lớp entity trong hệ thống
}
