package model;
import annotation.Entity;
@Entity
public class Reader {
    private String readerId;
    private String name;
    private String phone;

    public Reader(String readerId, String name, String phone) {
        this.readerId = readerId;
        this.name = name;
        this.phone = phone;
    }

    // Getters and Setters
    public String getReaderId() { return readerId; }
    public void setReaderId(String readerId) { this.readerId = readerId; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
}
