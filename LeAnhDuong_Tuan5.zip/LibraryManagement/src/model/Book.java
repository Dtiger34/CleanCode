package model;
import annotation.Entity;
import contract.IBorrowable;
@Entity
public class Book implements IBorrowable {
    private String bookId;
    private String title;
    private Author author;
    private String genre;
    private int quantity;

    public Book(String bookId, String title, Author author, String genre, int quantity) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.quantity = quantity;
    }

    // Getters and Setters
    public String getBookId() { return bookId; }
    public void setBookId(String bookId) { this.bookId = bookId; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public Author getAuthor() { return author; }
    public void setAuthor(Author author) { this.author = author; }
    public String getGenre() { return genre; }
    public void setGenre(String genre) { this.genre = genre; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    @Override
    public void borrow() {
        if (quantity > 0) {
            quantity--;
            System.out.println("You borrowed: " + title);
        } else {
            System.out.println("Sorry, this book is out of stock.");
        }
    }

    @Override
    public void returnBook() {
        quantity++;
        System.out.println("You returned: " + title);
    }
}
