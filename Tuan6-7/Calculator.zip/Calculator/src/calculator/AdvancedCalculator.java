/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculator;

/**
 *
 * @author duong
 */
public class AdvancedCalculator extends BasicCalculator {
     public double sqrt(double number) {
        try {
            if (number < 0) {
                throw new IllegalArgumentException("Lỗi: Không thể tính căn bậc hai của số âm.");
            }
            return Math.sqrt(number);
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
            return -1;
        }
    }
}
