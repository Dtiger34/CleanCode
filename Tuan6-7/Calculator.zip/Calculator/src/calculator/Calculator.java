/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculator;

/**
 *
 * @author duong
 */
public class Calculator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       BasicCalculator calc = new BasicCalculator();
        System.out.println("Kết quả chia: " + calc.divide(10, 0));

        AdvancedCalculator advCalc = new AdvancedCalculator();
        try {
            System.out.println("Căn bậc hai: " + advCalc.sqrt(-9));
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
        }

        String text = null;
        try {
            System.out.println(text.length());
        } catch (NullPointerException e) {
            System.out.println("Lỗi: Biến text đang null, hãy kiểm tra trước khi sử dụng.");
        }
    }
    
}
